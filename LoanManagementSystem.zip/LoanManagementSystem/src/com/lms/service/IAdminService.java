package com.lms.service;

import com.lms.entity.LoanProgramsOffered;
import com.lms.exception.LmsException;

public interface IAdminService {
	public boolean isLoanProgramInserted(LoanProgramsOffered loanProgramsOffered) throws LmsException;

}
