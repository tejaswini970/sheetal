package com.lms.dao;

import com.lms.entity.LoanProgramsOffered;
import com.lms.exception.LmsException;

public interface IAdminDao {
public boolean isLoanProgramInserted(LoanProgramsOffered loanProgramsOffered) throws LmsException;
}
