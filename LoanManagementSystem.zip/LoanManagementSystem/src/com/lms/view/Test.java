package com.lms.view;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.lms.entity.LoanProgramsOffered;
import com.lms.entity.Users;
import com.lms.exception.LmsException;
import com.lms.service.AdminServiceImpl;
import com.lms.service.IAdminService;
import com.lms.service.IUserService;
import com.lms.service.UserServiceImpl;

public class Test {

	public static void main(String[] args) throws IOException, LmsException {
		IUserService userservice=new UserServiceImpl();
		IAdminService adminService= new AdminServiceImpl();
		Users users = new Users();
		LoanProgramsOffered loanProgramOffered = new LoanProgramsOffered();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		// TO INSERT ADMIN N LAD
		/*
		 * System.out.println("username"); users.setLoginId(br.readLine());
		 * System.out.println("password"); users.setPassword(br.readLine());
		 * System.out.println("role"); users.setRole(br.readLine()); Users
		 * u=userservice.addUser(users); System.out.println(u);
		 */

		// TO CHECK VALID USER OR NOT
		/*
		 * String[] credential=new String[2]; System.out.println("Enter username");
		 * credential[0]=br.readLine(); System.out.println("enter Password");
		 * credential[1]=br.readLine(); boolean
		 * isAuthentic=userservice.authenticUser(credential);
		 * System.out.println(isAuthentic);
		 */

		// TO INSERT LOAN PROGRAM OFFERED
		/*System.out.println("enetr program name");
		loanProgramOffered.setProgramName(br.readLine());
		System.out.println("enter description");
		loanProgramOffered.setDescription(br.readLine());
		System.out.println("enter type");
		loanProgramOffered.setType(br.readLine());
		System.out.println("enter duration in years");
		loanProgramOffered.setDurationInYears(Integer.parseInt(br.readLine()));
		System.out.println("enter min loan amount");
		loanProgramOffered.setMinLoanAmount(Integer.parseInt(br.readLine()));
		System.out.println("enter max loan amount");
		loanProgramOffered.setMaxLoanAmount(Integer.parseInt(br.readLine()));
		System.out.println("enter rate");
		loanProgramOffered.setRateOfInterest(Integer.parseInt(br.readLine()));
		System.out.println("enter proofs");
		loanProgramOffered.setProofsRequired(br.readLine());
		
		boolean isInserted=adminService.isLoanProgramInserted(loanProgramOffered);
		System.out.println(isInserted);*/

	}

}
