package com.capgemini.laps.bean;

import java.sql.Date;

public class CustomerDetails {
	

   private String applicantName;
	private int applicationId;
	private Date dateOfBirth;
	private String maritalStatusString;
	private int phoneNo;
	private int mobileNo;
	private int countOfDependents;
	private String emailId;
	
	public CustomerDetails() {
		super();
	}

	public CustomerDetails(String applicantName, int applicationId,
			Date dateOfBirth, String maritalStatusString, int phoneNo,
			int mobileNo, int countOfDependents, String emailId) {
		super();
		this.applicantName = applicantName;
		this.applicationId = applicationId;
		this.dateOfBirth = dateOfBirth;
		this.maritalStatusString = maritalStatusString;
		this.phoneNo = phoneNo;
		this.mobileNo = mobileNo;
		this.countOfDependents = countOfDependents;
		this.emailId = emailId;
	}

	public String getApplicantName() {
		return applicantName;
	}

	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}

	public int getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getMaritalStatusString() {
		return maritalStatusString;
	}

	public void setMaritalStatusString(String maritalStatusString) {
		this.maritalStatusString = maritalStatusString;
	}

	public int getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(int phoneNo) {
		this.phoneNo = phoneNo;
	}

	public int getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}

	public int getCountOfDependents() {
		return countOfDependents;
	}

	public void setCountOfDependents(int countOfDependents) {
		this.countOfDependents = countOfDependents;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	@Override
	public String toString() {
		return "CustomerDetails [applicantName=" + applicantName
				+ ", applicationId=" + applicationId + ", dateOfBirth="
				+ dateOfBirth + ", maritalStatusString=" + maritalStatusString
				+ ", phoneNo=" + phoneNo + ", mobileNo=" + mobileNo
				+ ", countOfDependents=" + countOfDependents + ", emailId="
				+ emailId + "]";
	}
	
	
}
