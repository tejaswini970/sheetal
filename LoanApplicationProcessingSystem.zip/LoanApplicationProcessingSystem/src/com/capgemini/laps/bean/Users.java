package com.capgemini.laps.bean;

public class Users {
	private String loginId;
	private String passwordString;
	private String role;
	
	
	public Users() {
		super();
	}


	public Users(String loginId, String passwordString, String role) {
		super();
		this.loginId = loginId;
		this.passwordString = passwordString;
		this.role = role;
	}


	public String getLoginId() {
		return loginId;
	}


	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}


	public String getPasswordString() {
		return passwordString;
	}


	public void setPasswordString(String passwordString) {
		this.passwordString = passwordString;
	}


	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}


	@Override
	public String toString() {
		return "Users [loginId=" + loginId + ", passwordString="
				+ passwordString + ", role=" + role + "]";
	}
	
	

}
