package com.capgemini.laps.bean;

import java.sql.Date;

public class LoanProgrammeOffered {
	
	private int rateOfInterest;
	private String proofsRequiredString;
	private int durationInYears;
	private int minLoanAmount;
	private int maxLoanAmount;
	private String programName;
	private String description;
	private String type;
	
	public LoanProgrammeOffered() {
		super();
	}

	public LoanProgrammeOffered(int rateOfInterest,
			String proofsRequiredString, int durationInYears,
			int minLoanAmount, int maxLoanAmount, String programName,
			String description, String type) {
		super();
		this.rateOfInterest = rateOfInterest;
		this.proofsRequiredString = proofsRequiredString;
		this.durationInYears = durationInYears;
		this.minLoanAmount = minLoanAmount;
		this.maxLoanAmount = maxLoanAmount;
		this.programName = programName;
		this.description = description;
		this.type = type;
	}

	public int getRateOfInterest() {
		return rateOfInterest;
	}

	public void setRateOfInterest(int rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}

	public String getProofsRequiredString() {
		return proofsRequiredString;
	}

	public void setProofsRequiredString(String proofsRequiredString) {
		this.proofsRequiredString = proofsRequiredString;
	}

	public int getDurationInYears() {
		return durationInYears;
	}

	public void setDurationInYears(int durationInYears) {
		this.durationInYears = durationInYears;
	}

	public int getMinLoanAmount() {
		return minLoanAmount;
	}

	public void setMinLoanAmount(int minLoanAmount) {
		this.minLoanAmount = minLoanAmount;
	}

	public int getMaxLoanAmount() {
		return maxLoanAmount;
	}

	public void setMaxLoanAmount(int maxLoanAmount) {
		this.maxLoanAmount = maxLoanAmount;
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "LoanProgrammeOffered [rateOfInterest=" + rateOfInterest
				+ ", proofsRequiredString=" + proofsRequiredString
				+ ", durationInYears=" + durationInYears + ", minLoanAmount="
				+ minLoanAmount + ", maxLoanAmount=" + maxLoanAmount
				+ ", programName=" + programName + ", description="
				+ description + ", type=" + type + "]";
	}
	
	
	
	

}
