package com.capgemini.laps.bean;

public enum Status {
	applied,accepted,rejected

}
