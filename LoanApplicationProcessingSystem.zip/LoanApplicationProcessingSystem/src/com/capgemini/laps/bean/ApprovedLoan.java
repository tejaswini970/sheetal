package com.capgemini.laps.bean;

public class ApprovedLoan {
	 private String customerNameString;
	 private int amountOfLoanGranted;
	 private int monthlyInstallment;
	 private int yearsTimePeriod;
	 private int downPayement;
	 private int rateOfInterest;
	 private int totalAmountPayable;
	 
	public ApprovedLoan() {
		super();
	}

	public ApprovedLoan(String customerNameString, int amountOfLoanGranted,
			int monthlyInstallment, int yearsTimePeriod, int downPayement,
			int rateOfInterest, int totalAmountPayable) {
		super();
		this.customerNameString = customerNameString;
		this.amountOfLoanGranted = amountOfLoanGranted;
		this.monthlyInstallment = monthlyInstallment;
		this.yearsTimePeriod = yearsTimePeriod;
		this.downPayement = downPayement;
		this.rateOfInterest = rateOfInterest;
		this.totalAmountPayable = totalAmountPayable;
	}

	public String getCustomerNameString() {
		return customerNameString;
	}

	public void setCustomerNameString(String customerNameString) {
		this.customerNameString = customerNameString;
	}

	public int getAmountOfLoanGranted() {
		return amountOfLoanGranted;
	}

	public void setAmountOfLoanGranted(int amountOfLoanGranted) {
		this.amountOfLoanGranted = amountOfLoanGranted;
	}

	public int getMonthlyInstallment() {
		return monthlyInstallment;
	}

	public void setMonthlyInstallment(int monthlyInstallment) {
		this.monthlyInstallment = monthlyInstallment;
	}

	public int getYearsTimePeriod() {
		return yearsTimePeriod;
	}

	public void setYearsTimePeriod(int yearsTimePeriod) {
		this.yearsTimePeriod = yearsTimePeriod;
	}

	public int getDownPayement() {
		return downPayement;
	}

	public void setDownPayement(int downPayement) {
		this.downPayement = downPayement;
	}

	public int getRateOfInterest() {
		return rateOfInterest;
	}

	public void setRateOfInterest(int rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}

	public int getTotalAmountPayable() {
		return totalAmountPayable;
	}

	public void setTotalAmountPayable(int totalAmountPayable) {
		this.totalAmountPayable = totalAmountPayable;
	}

	@Override
	public String toString() {
		return "ApprovedLoan [customerNameString=" + customerNameString
				+ ", amountOfLoanGranted=" + amountOfLoanGranted
				+ ", monthlyInstallment=" + monthlyInstallment
				+ ", yearsTimePeriod=" + yearsTimePeriod + ", downPayement="
				+ downPayement + ", rateOfInterest=" + rateOfInterest
				+ ", totalAmountPayable=" + totalAmountPayable + "]";
	}
	 
	 
	 

}
