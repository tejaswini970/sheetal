package com.capgemini.laps.bean;

import java.sql.Date;

public class LoanApplication {
	private int applicationId;
	private Date applicationDate;
	private String loanProgram;
	private double amountOfLoan;
	private String addressOfProperty;
	private int annualFamilyIncome;
	private String documentProofsAvailable;
	private String guranteeCover;
	private int marketValueOfGuranteeCover;
	private String status;
	private Date dateOfInterview;
	
	public LoanApplication() {
		super();
	}

	public LoanApplication(int applicationId, Date applicationDate,
			String loanProgram, double amountOfLoan, String addressOfProperty,
			int annualFamilyIncome, String documentProofsAvailable,
			String guranteeCover, int marketValueOfGuranteeCover,
			String status, Date dateOfInterview) {
		super();
		this.applicationId = applicationId;
		this.applicationDate = applicationDate;
		this.loanProgram = loanProgram;
		this.amountOfLoan = amountOfLoan;
		this.addressOfProperty = addressOfProperty;
		this.annualFamilyIncome = annualFamilyIncome;
		this.documentProofsAvailable = documentProofsAvailable;
		this.guranteeCover = guranteeCover;
		this.marketValueOfGuranteeCover = marketValueOfGuranteeCover;
		this.status = status;
		this.dateOfInterview = dateOfInterview;
	}

	public int getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}

	public Date getApplicationDate() {
		return applicationDate;
	}

	public void setApplicationDate(Date applicationDate) {
		this.applicationDate = applicationDate;
	}

	public String getLoanProgram() {
		return loanProgram;
	}

	public void setLoanProgram(String loanProgram) {
		this.loanProgram = loanProgram;
	}

	public double getAmountOfLoan() {
		return amountOfLoan;
	}

	public void setAmountOfLoan(double amountOfLoan) {
		this.amountOfLoan = amountOfLoan;
	}

	public String getAddressOfProperty() {
		return addressOfProperty;
	}

	public void setAddressOfProperty(String addressOfProperty) {
		this.addressOfProperty = addressOfProperty;
	}

	public int getAnnualFamilyIncome() {
		return annualFamilyIncome;
	}

	public void setAnnualFamilyIncome(int annualFamilyIncome) {
		this.annualFamilyIncome = annualFamilyIncome;
	}

	public String getDocumentProofsAvailable() {
		return documentProofsAvailable;
	}

	public void setDocumentProofsAvailable(String documentProofsAvailable) {
		this.documentProofsAvailable = documentProofsAvailable;
	}

	public String getGuranteeCover() {
		return guranteeCover;
	}

	public void setGuranteeCover(String guranteeCover) {
		this.guranteeCover = guranteeCover;
	}

	public int getMarketValueOfGuranteeCover() {
		return marketValueOfGuranteeCover;
	}

	public void setMarketValueOfGuranteeCover(int marketValueOfGuranteeCover) {
		this.marketValueOfGuranteeCover = marketValueOfGuranteeCover;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getDateOfInterview() {
		return dateOfInterview;
	}

	public void setDateOfInterview(Date dateOfInterview) {
		this.dateOfInterview = dateOfInterview;
	}

	@Override
	public String toString() {
		return "LoanApplication [applicationId=" + applicationId
				+ ", applicationDate=" + applicationDate + ", loanProgram="
				+ loanProgram + ", amountOfLoan=" + amountOfLoan
				+ ", addressOfProperty=" + addressOfProperty
				+ ", annualFamilyIncome=" + annualFamilyIncome
				+ ", documentProofsAvailable=" + documentProofsAvailable
				+ ", guranteeCover=" + guranteeCover
				+ ", marketValueOfGuranteeCover=" + marketValueOfGuranteeCover
				+ ", status=" + status + ", dateOfInterview=" + dateOfInterview
				+ "]";
	}
	
	
	
	
	
	
	

}
